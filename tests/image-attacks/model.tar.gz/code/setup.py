from setuptools import setup
setup(name='inference', version='1.0', py_modules=['inference'])
