
import json
import os
import pickle

import numpy as np


def model_fn(model_dir):
    """Load model and scaler from the model directory."""
    with open(os.path.join(model_dir, "model.pkl"), "rb") as f:
        model = pickle.load(f)
    with open(os.path.join(model_dir, "scaler.pkl"), "rb") as f:
        scaler = pickle.load(f)
    return {"model": model, "scaler": scaler}


def input_fn(request_body, content_type="application/json"):
    """Parse input data from the request."""
    if content_type == "application/json":
        data = json.loads(request_body)
        if "instances" in data:
            features = [inst["features"] for inst in data["instances"]]
        elif "features" in data:
            features = [data["features"]]
        elif isinstance(data, list):
            features = data
        else:
            raise ValueError(f"Unsupported JSON format: {list(data.keys())}")
        return np.array(features, dtype=np.float64)
    raise ValueError(f"Unsupported content type: {content_type}")


def predict_fn(input_data, model_dict):
    """Run prediction."""
    scaler = model_dict["scaler"]
    model = model_dict["model"]

    scaled = scaler.transform(input_data)
    predictions = model.predict(scaled)
    probabilities = model.predict_proba(scaled)

    results = []
    for pred, proba in zip(predictions, probabilities):
        results.append({
            "class": int(pred),
            "label": "fraud" if pred == 1 else "legit",
            "confidence": float(proba[int(pred)]),
            "fraud_probability": float(proba[1]),
        })
    return results


def output_fn(prediction, accept="application/json"):
    """Format the prediction output."""
    return json.dumps({"predictions": prediction}), accept
